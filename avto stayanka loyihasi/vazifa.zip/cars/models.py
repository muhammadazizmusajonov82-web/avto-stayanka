from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import math


class CarParking(models.Model):
    # Mashina ma'lumotlari
    plate_number = models.CharField(max_length=20, verbose_name="Mashina raqami")
    car_model = models.CharField(max_length=50, verbose_name="Mashina rusumi")

    # Vaqt ko'rsatkichlari
    arrival_time = models.DateTimeField(default=timezone.now, verbose_name="Kirgan vaqti")
    departure_time = models.DateTimeField(null=True, blank=True, verbose_name="Chiqqan vaqti")

    # Holat va To'lov
    is_active = models.BooleanField(default=True, verbose_name="Hozir stayankadami?")
    total_charge = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, verbose_name="To'lov summasi")

    def calculate_fee(self):
        """ Mashina chiqib ketayotganda to'lovni hisoblash funksiyasi """
        if not self.departure_time:
            self.departure_time = timezone.now()

        # Umumiy turgan vaqtni soniyalarda aniqlash
        duration = self.departure_time - self.arrival_time
        total_minutes = duration.total_seconds() / 60

        # 1 soat (60 daqiqa) tekin
        if total_minutes <= 60:
            self.total_charge = 0
        else:
            # 1 soatdan ortgan qismini hisoblash
            chargeable_minutes = total_minutes - 60
            # Har bir boshlangan soatni yaxlitlash (masalan, 1.1 soat -> 2 soat)
            chargeable_hours = math.ceil(chargeable_minutes / 60)
            self.total_charge = chargeable_hours * 1500

        self.is_active = False
        self.save()

    def __str__(self):
        return f"{self.plate_number} ({self.car_model})"

    # files: cars/models.py ichiga qo'shing

    def get_duration_string(self):
        """ Mashina hozirgacha necha soat va daqiqa turganini matn ko'rinishida qaytaradi """
        from django.utils import timezone

        # Agar mashina hali chiqib ketmagan bo'lsa, hozirgi vaqt bilan hisoblaydi
        end_time = self.departure_time if self.departure_time else timezone.now()
        duration = end_time - self.arrival_time

        total_seconds = int(duration.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60

        if hours > 0:
            return f"{hours} soat, {minutes} daqiqa"
        return f"{minutes} daqiqa"
